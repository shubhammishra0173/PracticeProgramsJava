package Primenummber;

public class test16 {
	public static void main(String[] args) {
		int num=23,temp;
		boolean isprime =true;
		for(int i=2;i<num;i++)
		{
			temp=num%i;
			if(temp==0)
			{
				isprime = false;
				break;
			}
		}
		if(isprime)
		{
			System.out.println("this is a prime number "+num);
		}
		
	}

}
