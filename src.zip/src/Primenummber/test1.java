package Primenummber;

public class test1 {
public static void main (String[] args)
{
	int num =100,temp=0;
	
	for(int i =1;i<num;i++)
	{
		boolean isprime = true;
		for(int j =2;j<i;j++)

	{
			
			if(i%j==0)
			{
				isprime=false;
				break;
			}
			
	}
		if(isprime)
		{
			System.out.print("Prie numbers are " +i);
			System.out.println();
		}	
	}
	
}

	
}
