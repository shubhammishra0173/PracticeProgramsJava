package Primenummber;

public class test1between {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num =113;
int tmp=0;
boolean isprime = true;
for(int i=2;i<num/2;i++)
{
tmp=num%i;
if(tmp==0)
{
	isprime=false;
	break;
}
if(isprime){
System.out.println("number is prime");	
}

}
	}

}
