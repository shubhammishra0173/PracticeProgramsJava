package SplitAlphaNumeric;

public class Split5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str = "Test123@#";
String num = "";
String special="";
String letter="";
		
for(int i =0;i<str.length();i++)
{
	char a = str.charAt(i);
if(Character.isDigit(a))
{
	num=num+a;
}
else if(Character.isAlphabetic(a))
{
letter= letter+a;	
}
else
{
special=special+a;	
}
}
System.out.println(num);
System.out.println(letter);
System.out.println(special);
	}

}
