import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class test {

	

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	
	int []arr = {2,55,3,11,-1};
	
	
	System.out.println(processlist(arr));
	}
	public static int   processlist(int[] arr)
	{
		int n =0;
	//final Set<int>  resultset = new HashSet<int>();
	//final Set<String>  tempset = new HashSet<String>();
	for(int i =0;i<arr.length;i++)
	{
	if(arr[i]==2)
	{
n=arr[i];

	}
	}
	return n;

	}
	}