package SecondLargestArray;

public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {12,34,56,56,55};
int largest =0;
int secondlargest =0;
for(int i =0;i<arr.length;i++)
{
if(arr[i]>largest)
{
secondlargest = largest;
largest=arr[i];
}
else if(arr[i]>secondlargest&&arr[i]!=largest)
{
secondlargest=arr[i];	
}
}
System.out.println(largest);
System.out.println(secondlargest);
	}

}
