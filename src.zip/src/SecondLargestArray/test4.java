package SecondLargestArray;

public class test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[]arr= {12,345,56,67,45,345,444};
int largest =0;
int secondlargest=0;
for(int i=0;i<arr.length;i++)
{
if(arr[i]>largest)	
}
	}

}
