package DuplicateCharacter;

public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String name = new String("Sakkeatt msishra");
int count =0;
char [] ch = name.toCharArray();
System.out.println("Duplicate characters are");

for(int i =0;i<name.length();i++)
{
for(int j =i+1;j<name.length();j++)
{
if(ch[i]==ch[j])
{
System.out.println(ch[j]);	
count++;
break;
}
}
}
	}

}
