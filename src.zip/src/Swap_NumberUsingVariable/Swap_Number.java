package Swap_NumberUsingVariable;

public class Swap_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x = 15;
int y =20;

x = x+y;
y = x-y;
x= x-y;
System.out.println(x +"++" +y);
	}

}
