package multiinheritanceinterfacepra;

interface test1 {
	void testing();
}
