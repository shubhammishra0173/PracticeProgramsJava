package multiinheritanceinterfacepra;

 interface test {
	void testing();
	
}
