package removeDuplicateArray;

public class test15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int []num = {12,34,56,78,23,34,34};
int count;
int temp;
for(int i = 0;i<num.length;i++)
{ count =1;
for(int j =i+1;j<num.length;j++)
{ 
if(num[i]==num[j])
{
count++;
num[j]=0;

break;
}


if(count>1&&num[i]!=0)
{
	//System.out.println(num[i]);
	temp=num[j];System.out.println(temp);
}
}
}
	}

}
