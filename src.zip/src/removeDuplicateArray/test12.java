package removeDuplicateArray;

import java.util.Arrays;

public class test12 {

	public static int[] removeDuplicateArray(int arr[])
	{
		int n = arr.length;
		int j =0;
		int []temp= new int [n];
		for(int i =0;i<n-1;i++)
		{
			if(arr[i]!=arr[i+1])
			{
				temp[j++]=arr[i];
			}
		}
		temp[j++]=arr[n-1];
		return temp;
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {12,34,5,6,12,5,67,5,6,7,7};
Arrays.sort(arr);
int[] result = removeDuplicateArray(arr);
for(int i =0;i<result.length;i++)
{
if(result[i]!=0)
{
System.out.println(result[i]);	
}
}
	}

}
