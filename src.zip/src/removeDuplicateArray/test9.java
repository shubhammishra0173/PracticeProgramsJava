package removeDuplicateArray;

import java.util.Arrays;

public class test9 {
	public static int[] removeduplicatearray(int arr[])
	{
		int n = arr.length;
		int j =0;
		int []temp = new int[n];
		for(int i =0;i<n-1;i++)
		{
			if(arr[i]!=arr[i+1])
			{
				temp[j++]=arr[i];
			}
		}
		temp[j++]=arr[n-1];
		return temp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {12,34,56,78,12,34,56};
Arrays.sort(arr);
int []result = removeduplicatearray(arr);
for(int i=0;i<result.length;i++)
{
if(result[i]!=0)
{
System.out.print(result[i] +" ");	
}
}
		
	}

}
