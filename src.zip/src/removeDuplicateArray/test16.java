package removeDuplicateArray;

import java.util.Arrays;

public class test16 {
	public static int[] removeduplicatearray(int arr[])
	{
		int n =arr.length;
		int j =0;
		int[]temp= new int[n];
		for(int i =0;i<n-1;i++)
		{
		if(arr[i]!=arr[i+1])
		{
			temp[j++]=arr[i];
			
		}
		}
		temp[j++]=arr[n-1];
		return temp;
	}
	public static void main(String[] args) {
		
		int[]arr= {12,12,34,56,78,12,34};
		Arrays.sort(arr);
		int []resultset=removeduplicatearray(arr);
		for(int i=0;i<resultset.length;i++)
		{
			if(resultset[i]!=0)
			{
				System.out.println(resultset[i]);
				
			}
		}
	}

}
