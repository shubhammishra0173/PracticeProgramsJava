package removeDuplicateArray;

import java.util.Arrays;

public class test8 {

	public static int[] removearray(int arr[]) {
		
		int n=arr.length;
		int j=0;
		int[]temp =new int[n];
		
		for(int i=0;i<n-1;i++)
		{
			if(arr[i]!=arr[i+1])
			{
				temp[j++]=arr[i];
			}
		}
		temp[j++]=arr[n-1];
		return temp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]arr= {12,34,45,65,12,45,78,78};
		Arrays.sort(arr);
		int[] resultset = removearray(arr);
		for(int i=0;i<resultset.length;i++)
		{
			if(resultset[i]!=0)
			{
				System.out.print(resultset[i] +" ");
			}
		}
		

	}

}
