package removeDuplicateArray;

import java.util.Arrays;

public class test13 {

	public static int[] removeduplicateArray(int arr[])
	{
		int n = arr.length;
		int j =0;
		int[]temp = new int[n];
		for(int i =0;i<n-1;i++)
		{
			if(arr[i]!=arr[i+1])
			{
				temp[j++]=arr[i];
			}
		}
		temp[j++]=arr[n-1];
		return temp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {12,23,45,12,45,12,34,34,23};
Arrays.sort(arr);
int[]result =removeduplicateArray(arr);
for(int i =0;i<result.length;i++)
{
	if(result[i]!=0)
	{
		System.out.println(result[i]);
	}
}

	}

}
