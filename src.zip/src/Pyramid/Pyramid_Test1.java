package Pyramid;

public class Pyramid_Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(int outer=1;outer<=5;outer++)
{
	for(int inner=1;inner<=outer;inner++)
	{
	System.out.print("*");	

	}
	System.out.println();
}
	}

}
